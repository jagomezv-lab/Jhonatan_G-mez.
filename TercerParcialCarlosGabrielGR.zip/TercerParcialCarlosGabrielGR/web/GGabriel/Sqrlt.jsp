<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Sqrlt</title>
        <link rel="stylesheet" href="estilos/formus.css">
        <style>
            /* Contenedor principal */
            .container {
                width: 80%;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
                font-family: Arial, sans-serif;
            }

            /* Título principal */
            .title {
                font-size: 2.5em;
                color: #333;
                margin-bottom: 20px;
            }

            /* Descripción */
            .description {
                font-size: 1.2em;
                color: #555;
                margin-bottom: 30px;
                text-align: left;
            }

            /* Estilo del formulario */
            .form {
                display: inline-block;
                text-align: left;
                background-color: #f4f4f4;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .input-field {
                padding: 8px;
                margin: 10px 0;
                width: 250px;
                border: 1px solid #ccc;
                border-radius: 4px;
                font-size: 1em;
            }

            .submit-btn {
                padding: 10px 15px;
                font-size: 1.2em;
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }

            .submit-btn:hover {
                background-color: #45a049;
            }

            .back-link {
                display: inline-block;
                margin-top: 20px;
                text-decoration: none;
                color: black;
                font-size: 1.1em;
            }

            .back-link:hover {
                text-decoration: none;
                color: gray;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1 class="title">Funcion sqrt</h1>
        
            <h4 class="description">
                sqrt es una función matemática que se utiliza para calcular la raíz cuadrada de un número. 
                Se encuentra en muchas bibliotecas estándar de lenguajes de programación, como la clase Math en Java. 
                Su propósito es devolver un valor que, elevado al cuadrado, sea igual al número de entrada. Por ejemplo,
                Math.sqrt(25) devuelve 5.0, ya que 5 × 5 = 25. Es una función útil en cálculos matemáticos,
                algoritmos y aplicaciones científicas.
            </h4>
            
            <form action="../Controlador" class="form" method="post" >
                <input type="hidden" name="funcion" value="sqrlt">
                
                <label>Ingresa cualquier numero: 
                    <input type="number" class="input-field" name="raiz" value="<%= request.getAttribute("valorIngresado") != null ? request.getAttribute("valorIngresado") : "" %>">
                </label><br>
                <br>
                <label>Resultado: 
                    <input type="text" class="input-field" readonly 
                    value="<%= request.getAttribute("resultado") != null ? request.getAttribute("resultado") : "" %>">
                </label><br>
                <br>
                <input type="submit" value="Calcular Raiz" class="submit-btn">
            </form>
            
            <br>
            <a href="index.jsp" class="back-link">Volver al inicio</a>
        </div>
    </body>
</html>
