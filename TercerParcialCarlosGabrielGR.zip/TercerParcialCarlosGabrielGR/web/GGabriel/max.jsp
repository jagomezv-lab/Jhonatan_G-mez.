<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>max</title>
        <style>
            /* Contenedor principal */
            .container {
                width: 80%;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
                font-family: Arial, sans-serif;
            }

            /* Título principal */
            .title {
                font-size: 2.5em;
                color: #333;
                margin-bottom: 20px;
            }

            /* Descripción */
            .description {
                font-size: 1.2em;
                color: #555;
                margin-bottom: 30px;
                text-align: left;
            }

            /* Estilo del formulario */
            .form {
                display: inline-block;
                text-align: left;
                background-color: #f4f4f4;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .input-field {
                padding: 8px;
                margin: 10px 0;
                width: 250px;
                border: 1px solid #ccc;
                border-radius: 4px;
                font-size: 1em;
            }

            .submit-btn {
                padding: 10px 15px;
                font-size: 1.2em;
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }

            .submit-btn:hover {
                background-color: #45a049;
            }

            .back-link {
                display: inline-block;
                margin-top: 20px;
                text-decoration: none;
                color: black;
                font-size: 1.1em;
            }

            .back-link:hover {
                text-decoration: none;
                color: gray;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1 class="title">Clase max</h1>
            
            <h4 class="description">
                La función <code>max</code> es un método matemático utilizado para determinar el mayor de dos valores.
                En muchos lenguajes de programación, como Java, se encuentra en la clase <code>Math</code> y devuelve el
                valor más grande entre los dos argumentos proporcionados. 
                Su sintaxis en Java es <code>Math.max(valor1, valor2)</code>, y puede usarse con diferentes 
                tipos numéricos, como <code>int</code>, <code>double</code> o <code>float</code>. Por ejemplo, 
                <code>Math.max(10, 5)</code> devuelve <code>10</code>, ya que es el mayor de los dos valores. 
                Esta función es útil en comparaciones, optimización de algoritmos y cálculos matemáticos.
            </h4>
                
            <form class="form" action="../Controlador" method="post">
                <input type="hidden" name="funcion" value="max">
                
                <label>Ingresa el primer número: <input type="number" class="input-field" name="n1" value="<%= request.getParameter("n1") != null ? request.getParameter("n1") : "" %>"></label><br>
                
                <br><label>Ingresa el segundo número: <input type="number" class="input-field" name="n2" value="<%= request.getParameter("n2") != null ? request.getParameter("n2") : "" %>"></label><br>
                
                <br><label>El número más grande es: <input type="text" class="input-field" readonly 
                    value="<%= request.getAttribute("resultado") != null ? request.getAttribute("resultado") : "" %>"></label><br>
                
                <br><input type="submit" value="Mostrar el más grande" class="submit-btn">
            </form>
                
            <br><a href="index.jsp" class="back-link">Volver al inicio</a>
        </div>
    </body>
</html>
