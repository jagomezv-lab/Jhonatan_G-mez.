<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Pow</title>
        <style>
            /* Contenedor principal */
            .container {
                width: 80%;
                margin: 0 auto;
                padding: 20px;
                text-align: center;
                font-family: Arial, sans-serif;
            }

            /* Título principal */
            .title {
                font-size: 2.5em;
                color: #333;
                margin-bottom: 20px;
            }

            /* Descripción */
            .description {
                font-size: 1.2em;
                color: #555;
                margin-bottom: 30px;
                text-align: left;
            }

            /* Estilo del formulario */
            .form {
                display: inline-block;
                text-align: left;
                background-color: #f4f4f4;
                padding: 20px;
                border-radius: 8px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            }

            .input-field {
                padding: 8px;
                margin: 10px 0;
                width: 250px;
                border: 1px solid #ccc;
                border-radius: 4px;
                font-size: 1em;
            }

            .submit-btn {
                padding: 10px 15px;
                font-size: 1.2em;
                background-color: #4CAF50;
                color: white;
                border: none;
                border-radius: 4px;
                cursor: pointer;
            }

            .submit-btn:hover {
                background-color: #45a049;
            }

            .back-link {
                display: inline-block;
                margin-top: 20px;
                text-decoration: none;
                color: black;
                font-size: 1.1em;
            }

            .back-link:hover {
                text-decoration: none;
                color: gray;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <h1 class="title">Funcion pow</h1>
            
            <h4 class="description">
                La función pow es un método matemático utilizado para calcular la potencia de un número. 
                En muchos lenguajes de programación, como Java, se encuentra en la clase Math y permite 
                elevar un número base a un exponente determinado. Su sintaxis en Java es <code>Math.pow(base, exponente)</code>, 
                y devuelve un resultado de tipo double. Por ejemplo, <code>Math.pow(2, 3)</code> devuelve 8.0, ya que 2³ = 8. 
                Es ampliamente utilizada en cálculos científicos, ingeniería y desarrollo de algoritmos que requieren 
                operaciones exponenciales.
            </h4>
             
            <form class="form" action="../Controlador" method="post">
                <input type="hidden" name="funcion" value="pow">
                
                <label>Ingresa el número base: <input type="number" class="input-field" name="base" value="<%= request.getParameter("base") != null ? request.getParameter("base") : "" %>"></label><br>
                
                <br><label>Ingresa la potencia: <input type="number" class="input-field" name="potencia" value="<%= request.getParameter("potencia") != null ? request.getParameter("potencia") : "" %>"></label><br>
                
                <br><label>Resultado: <input type="text" class="input-field" readonly 
                    value="<%= request.getAttribute("resultado") != null ? request.getAttribute("resultado") : "" %>"></label><br>
                
                <br><input type="submit" value="Calcular potencia" class="submit-btn">
            </form>
             
                    <br><a href="index.jsp" class="back-link">Volver al inicio</a>
        </div>
    </body>
</html>
