<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Operaciones Matemáticas</title>
        <link rel="stylesheet" href="GGabriel/estilos/inicio.css">
    </head>
    <body>
        <h1>Clases Math</h1>
        <h2>Bienvenido</h2>
        
        <ul>
            <li><a href="GGabriel/Sqrlt.jsp">Entrar a sqrt</a></li>
            <li><a href="GGabriel/pow.jsp">Entrar a pow</a></li>
            <li><a href="GGabriel/min.jsp">Entrar a min</a></li>
            <li><a href="GGabriel/max.jsp">Entrar a max</a></li>
        </ul>
    </body>
</html>
