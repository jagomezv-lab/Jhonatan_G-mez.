package Controlador;

import Modelo.OpsMatematicas;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/Controlador"})
public class Controlador extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String funcion = request.getParameter("funcion");

        if (funcion != null) {
            switch (funcion) {
                case "sqrlt":
                    String raizs = request.getParameter("raiz");
                    if (raizs != null && !raizs.isEmpty()) {
                        double numRaiz = Double.parseDouble(raizs);
                        OpsMatematicas ops = new OpsMatematicas(numRaiz);
                        double resultado = Math.sqrt(numRaiz);

                        request.setAttribute("valorIngresado", numRaiz);
                        request.setAttribute("resultado", resultado);
                    }
                    request.getRequestDispatcher("./GGabriel/Sqrlt.jsp").forward(request, response);
                    break;

                case "pow":
                    String bases = request.getParameter("base");
                    String pots = request.getParameter("potencia");
                    if (bases != null && pots != null && !bases.isEmpty() && !pots.isEmpty()) {
                        int base = Integer.parseInt(bases);
                        int potencia = Integer.parseInt(pots);
                        OpsMatematicas ops = new OpsMatematicas(base, potencia);
                        int resultado = (int) Math.pow(base, potencia);

                        request.setAttribute("valorBase", base);
                        request.setAttribute("valorPotencia", potencia);
                        request.setAttribute("resultado", resultado);
                    }
                    request.getRequestDispatcher("./GGabriel/pow.jsp").forward(request, response);
                    break;

                case "max":
                    String max1s = request.getParameter("n1");
                    String max2s = request.getParameter("n2");
                    if (max1s != null && max2s != null && !max1s.isEmpty() && !max2s.isEmpty()) {
                        double max1 = Double.parseDouble(max1s);
                        double max2 = Double.parseDouble(max2s);
                        OpsMatematicas ops = new OpsMatematicas(max1, max2);
                        double resultado = Math.max(max1, max2);

                        request.setAttribute("numMax1", max1);
                        request.setAttribute("numMax2", max2);
                        request.setAttribute("resultado", resultado);
                    }
                    request.getRequestDispatcher("./GGabriel/max.jsp").forward(request, response);
                    break;

                case "min":
                    String min1s = request.getParameter("n1");
                    String min2s = request.getParameter("n2");
                    if (min1s != null && min2s != null && !min1s.isEmpty() && !min2s.isEmpty()) {
                        double min1 = Double.parseDouble(min1s);
                        double min2 = Double.parseDouble(min2s);
                        OpsMatematicas ops = new OpsMatematicas(min1, min2, 0);
                        double resultado = Math.min(min1, min2);

                        request.setAttribute("numMin1", min1);
                        request.setAttribute("numMin2", min2);
                        request.setAttribute("resultado", resultado);
                    }
                    request.getRequestDispatcher("./GGabriel/min.jsp").forward(request, response);
                    break;
            }
        }
    }
}
