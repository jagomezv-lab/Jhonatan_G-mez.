
package Modelo;

public class OpsMatematicas {
    
    private double numMin1,numMin2, numMax1,numMax2, numRaiz, resR, resMin, respMax;
    
    private int numBase, numPotencia, resP;

    public OpsMatematicas(double numMin1, double numMin2, double resMin) {
        this.numMin1 = numMin1;
        this.numMin2 = numMin2;
        this.resMin = resMin;
    }
 
    public OpsMatematicas (double numMax1, double numMax2){
    
    this.numMax1 = numMax1;
    this.numMax2 = numMax2;
        
    }

    public OpsMatematicas(double numRaiz) {
        this.numRaiz = numRaiz;
    }

    public OpsMatematicas(int numBase, int numPotencia) {
        this.numBase = numBase;
        this.numPotencia = numPotencia;
    }

    public double getNumMin1() {
        return numMin1;
    }

    public void setNumMin1(double numMin1) {
        this.numMin1 = numMin1;
    }

    public double getNumMin2() {
        return numMin2;
    }

    public void setNumMin2(double numMin2) {
        this.numMin2 = numMin2;
    }

    public double getNumMax1() {
        return numMax1;
    }

    public void setNumMax1(double numMax1) {
        this.numMax1 = numMax1;
    }

    public double getNumMax2() {
        return numMax2;
    }

    public void setNumMax2(double numMax2) {
        this.numMax2 = numMax2;
    }

    public double getNumRaiz() {
        return numRaiz;
    }

    public void setNumRaiz(double numRaiz) {
        this.numRaiz = numRaiz;
    }

    public int getNumBase() {
        return numBase;
    }

    public void setNumBase(int numBase) {
        this.numBase = numBase;
    }

    public int getNumPotencia() {
        return numPotencia;
    }

    public void setNumPotencia(int numPotencia) {
        this.numPotencia = numPotencia;
    }

    public double getResR() {
        return resR;
    }

    public double getResMin() {
        return resMin;
    }

    public double getRespMax() {
        return respMax;
    }

    public int getResP() {
        return resP;
    }
    
    
   
    
}
